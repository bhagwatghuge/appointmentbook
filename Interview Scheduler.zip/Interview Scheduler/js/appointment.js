let currentDate = new Date();
let selectedDay;
let appointments = {};

function renderCalendar() {
    const month = currentDate.getMonth();
    const year = currentDate.getFullYear();
    document.getElementById('monthDisplay').textContent = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });

    const calendarDays = document.getElementById('calendarDays');
    calendarDays.innerHTML = '';

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let i = 0; i < firstDay; i++) {
        calendarDays.appendChild(document.createElement('div')).classList.add('calendar-day');
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.classList.add('calendar-day');
        dayCell.dataset.day = day;
        dayCell.textContent = day;

        // Check if the day has appointments and add the booked class
        if (appointments[day] && appointments[day].length > 0) {
            dayCell.classList.add('booked');
        }

        const addButton = document.createElement('button');
        addButton.classList.add('add-button');
        addButton.textContent = '+';
        addButton.addEventListener('click', (e) => {
            e.stopPropagation();
            selectedDay = day;
            // Clear form fields
            document.getElementById('companyName').value = '';
            document.getElementById('startTime').value = '';
            document.getElementById('endTime').value = '';
            document.getElementById('interviewDetails').value = '';
            document.getElementById('appointmentForm').classList.add('active');
        });

        const popup = document.createElement('div');
        popup.classList.add('appointment-popup');
        popup.innerHTML = appointments[day]
            ? `<table class="table table-bordered mb-0"><tr><th>Time</th><th>Company</th></tr>${appointments[day].map(appt => `<tr><td>${appt.startTime}-${appt.endTime}</td><td>${appt.company}</td></tr>`).join('')}</table>`
            : "No booked slot";

        dayCell.appendChild(addButton);
        dayCell.appendChild(popup);
        calendarDays.appendChild(dayCell);
    }
}


document.getElementById('bookSlot').addEventListener('click', () => {
    if (!appointments[selectedDay]) appointments[selectedDay] = [];
    appointments[selectedDay].push({
        company: document.getElementById('companyName').value,
        startTime: document.getElementById('startTime').value,
        endTime: document.getElementById('endTime').value
    });

    // Close the appointment form
    document.getElementById('appointmentForm').classList.remove('active');

    // Find the day cell and add the 'booked' class dynamically
    const dayCells = document.querySelectorAll('.calendar-day');
    dayCells.forEach(dayCell => {
        if (parseInt(dayCell.dataset.day) === selectedDay) {
            dayCell.classList.add('booked');
        }
    });

    renderCalendar();  // Re-render to apply updates
});
document.getElementById('closeForm').addEventListener('click', () => document.getElementById('appointmentForm').classList.remove('active'));
renderCalendar();