document.addEventListener("DOMContentLoaded", function () {
let currentDate = new Date();
let appointments = {
3: [{ startTime: "10:00 AM", endTime: "11:00 AM", company: "Company A" }],
5: [{ startTime: "2:00 PM", endTime: "3:00 PM", company: "Company B" }],
};

function renderCalendar() {
const month = currentDate.getMonth();
const year = currentDate.getFullYear();
document.getElementById('monthDisplay').textContent = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });

const calendarDays = document.getElementById('calendarDays');
calendarDays.innerHTML = '';

const firstDay = new Date(year, month, 1).getDay();
const daysInMonth = new Date(year, month + 1, 0).getDate();

for (let i = 0; i < firstDay; i++) {
calendarDays.appendChild(document.createElement('div')).classList.add('calendar-day');
}

for (let day = 1; day <= daysInMonth; day++) {
const dayCell = document.createElement('div');
dayCell.classList.add('calendar-day');
dayCell.dataset.day = day;
dayCell.textContent = day;

if (appointments[day] && appointments[day].length > 0) {
    dayCell.classList.add('booked');
}

dayCell.addEventListener('click', function () {
    showAppointments(day);
});

calendarDays.appendChild(dayCell);
}
}

function showAppointments(day) {
const popup = document.getElementById("appointmentPopup");
const popupContent = document.getElementById("popupContent");

if (appointments[day] && appointments[day].length > 0) {
popupContent.innerHTML = `<h5>Appointments for Day ${day}</h5>
    <table class="table table-bordered mb-0">
        <tr><th>Sr. No.</th><th>Candidate Name</th><th>Time</th><th>Company</th><th>Round</th></tr>
        ${appointments[day].map(appt => `<tr><td>1</td><td>Bhagwat Ghuge</td><td>${appt.startTime}-${appt.endTime}</td><td>${appt.company}</td><td>Technical 2</td></tr>`).join('')}
    </table>`;
} else {
popupContent.innerHTML = `<h5>No appointments for Day ${day}</h5>`;
}

popup.classList.add("active");
}

document.getElementById("closePopup").addEventListener("click", function () {
document.getElementById("appointmentPopup").classList.remove("active");
});

renderCalendar();
});

